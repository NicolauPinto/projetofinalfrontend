import Vue from 'vue'
import VueRouter from 'vue-router'
import Home from '../views/Home.vue'
import Pacientes from '../views/Pacientes .vue'
import Login from '../views/Login.vue'
import Erro from '../views/Erro.vue'
import Registo from '../views/Registo.vue'
import DoenteRegistado from '../views/DoenteRegistado.vue'
import RegistarDoente from '../views/RegistarDoente.vue'


Vue.use(VueRouter)

const routes = [ 
  {
    path: '/',
    name: 'Home',
    component: Home
  },
  
  
  {
    path: '*',
    name: 'Erro',
    component: Erro
  },
  {
    path: '/Pacientes ',
    name: 'Pacientes ',
    component: Pacientes 
  },
  {
    path: '/Login',
    name: 'Login',
    component: Login
  },
  {
    path: '/DoenteRegistado',
    name: 'DoenteRegistado',
    component: DoenteRegistado
  },
  {
    path: '/Registo',
    name: 'Registo',
    component: Registo
  },
  {
    path: '/RegistarDoente',
    name: 'RegistarDoente',
    component: RegistarDoente
  },
 
]

const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes
})

export default router
