//Login.vue

<template>
  <v-app id="inspire">
    <v-main class="background">
      <v-form>
          <div class="centro">

         <v-card class="box">
            <h2 class="inisessao"> Registo </h2>

            <v-card-text>
               <v-text-field label="Username"/>
               <v-text-field label="Email" type="email" v-model="email_"/> 
               <v-text-field label="Criar password" type="password" v-model="password"/>
               <v-text-field label="Repetir a password" type="password"  />
            </v-card-text>


            <v-card-actions>
               <v-btn type="button" @click="registo()">
                  Registo
               </v-btn>
            </v-card-actions>
            <div v-if="mostrar">
         <v-alert
            color="#2A3B4D" dark
            icon="mdi-firework"
            dense
      >
      Erro de autenticação 
    </v-alert>
      </div>
         </v-card>
         </div>
      </v-form>
    </v-main>
  </v-app>
  
</template>
<script>

import firebase from 'firebase';

   export default {
   data() {
      return {
         signup: false,
         email_ : "",
         password: '',
         mostrar : false,
      };
      },
   methods: {
      aparecer_signup(){
         this.signup = true;
         this.$router.push("/Registo");
      },
      registo(){
          firebase.auth().createUserWithEmailAndPassword(this.email_, this.password)
            .then((userCredential) => {
                // Signed in
                var user = userCredential.user;
                console.log(user);
                this.$router.push("/Produto");
                
                // ...
            })
            .catch((error) => {
                var errorCode = error.code;
                var errorMessage = error.message;
                console.log(errorCode + errorMessage);
                this.$router.push("/Registo");
                this.mostrar = true;
                // ..
            });
      }
      },
   };

</script>



<style> 
   .box {
      width: 700px; 
      background-image: url("https://s3.envato.com/files/161385650/hospital_590.jpg");   
      background-size: cover;
      background-position: center;
      
   }

   .background {
      background-image: url("https://wallpaperaccess.com/full/1282794.jpg");
      background-size: cover;
      background-position: center;

   }

   .centro {
        display: flex;
        justify-content:flex-start;
        padding: 80px;
   }
   .inisessao {
      display: flex;
      justify-content: center;
      padding: 10px;

     
   }

</style> 
