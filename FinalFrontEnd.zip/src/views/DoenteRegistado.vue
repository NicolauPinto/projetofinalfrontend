<template>
 <v-app id="app">
  <v-container>
      <div>
        <v-card hover>
          
          <!-- <v-card-media
            src="https://hips.hearstapps.com/hmg-prod.s3.amazonaws.com/images/chest-freckles-1523910987.jpg?crop=1xw:1xh;center,top&resize=480:*"
            height="500px"
          >
          </v-card-media> -->
          <div class="row" >
          <v-card  width="200" v-for="(Doente, index) in info" :key="index">
            <h2>
            <p>{{Doente.Nome}}</p>
            <p>{{Doente.Apelido}}</p>
            </h2> 
            <p>{{Doente.Idade}}</p>
            <p>{{Doente.Pais_Origem}}</p>
            <p>{{Doente.Doença}}</p>
              <v-img  :src="Doente.Foto"></v-img>
          </v-card >
          </div>

 

          <!-- <v-card-title>
            <h2>Doente nº1</h2>
          </v-card-title>
          
          <v-card-text>
            Nome: Mariana Vasconcelos<br>
            Idade: 52 anos<br>
            Pais de Origem: Brasil <br>

            Cidade de Origem: Curitiba <br>
            Doença: Dor de Garganta
          </v-card-text>
          
          <v-card-actions>
            <v-btn color=success>Reservar Consulta</v-btn>
            <v-btn flat color=red>Apagar</v-btn>
            <v-spacer></v-spacer>
            <v-btn icon><v-icon>bookmark</v-icon></v-btn>
          </v-card-actions> -->
          
        </v-card>
      </div>
  </v-container>
</v-app>
</template>

<script>
import axios from "axios";
export default {
    name: 'App',
    data() {
    return {
        hospitalApi: null,
        info:"",
    };
  },
  mounted() {
    var that = this;
    axios
      .get("https://hospitalmadeira-default-rtdb.firebaseio.com/.json")
      .then(response => (this.info = response.data.Doente));
    console.log(that.info);
  },

      submeterFormulario() {
      return axios.post("https://hospitalmadeira-default-rtdb.firebaseio.com/Doente.json",this.novoDoente
      );
    },


}
</script>

<style scoped>
.h2{
        margin-left: px;
        margin-top:-80px
    }

html, body {
    height: 100%;
    margin: 0;
    padding: 0;
}

#app {
    font-family: Avenir, Helvetica, Arial, sans-serif;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
    text-align: center;
    color: #2c3e50;
    margin-top: 60px;
}

.novasCartasPesquisa {
  display: grid;
  grid-template-columns: 250px 250px 250px;
  padding-left: 0px;
  grid-gap: 30px;
  height: 361px;
  width: 255px;
}

.outer {
    display: flex;
    flex: 1;
    width: auto;
    height: 100%;
    padding: 0 20px;
    flex-flow: row nowrap;
    align-items: center;
}
.inner-content {
    flex-shrink: 0;
    align-items: center;
    justify-content: center;
    width: 100px;
    height: calc(100% - 40px);
    border: solid 1px #2c3e50;
    border-radius: 5px;
}
.inner-content:not(:first-of-type) {
    margin-left: 30px;
}
.container {
  display: flex;
  justify-content: center;
  align-items: center;
  width: 1200px;
  height: 100%;
}
</style>