<template>
    <div class="form">
        
        <div class = "input-control">
            <label> Id </label>
            <input type = "text" v-model="novoDoente.Id">
        </div>

        <div class = "input-control">
            <label> Nome </label>
            <input type = "text" v-model="novoDoente.Nome">
        </div>
 
        <div class = "input-control">
            <label> Apelido </label>
            <input type = "text" v-model="novoDoente.Apelido">
        </div>
 
        <div class = "input-control">
            <label> Idade </label>
            <input type = "text" v-model="novoDoente.Idade">
        </div>

        <div class = "input-control">
            <label> Pais de Origem </label>
            <input type = "text" v-model="novoDoente.Pais_Origem">
        </div>

        <div class = "input-control">
            <label> Cidade de Origem </label>
            <input type = "text" v-model="novoDoente.Cidade_Origem">
        </div>

        <div class = "input-control">
            <label> Doenca </label>
            <input type = "text" v-model="novoDoente.Doenca">
        </div>

        <div class = "input-control">
            <label> Foto </label>
            <input type = "text" v-model="novoDoente.Foto">
        </div>
 
        <input type = "submit" value="Enviar" @click="submeterFormulario()"/>
 
    </div>
</template>
<script>
import axios from 'axios'
 
export default  {
    data() {
        return {
            novoDoente: {
                Id: '',
                Nome: '',
                Apelido: '',
                Idade: '',
                Pais_Origem:'',
                Cidade_Origem: '',
                Doenca: '',
                Foto: ''
            }
        }
    },

    methods: {
        submeterFormulario() {
            alert("Novo Doente registado com sucesso");
            return axios.post('https://hospitalmadeira-default-rtdb.firebaseio.com/Doente.json', this.novoDoente);
        }
    }
}

</script>

<style scoped>

.form {
    max-width: 550px;
    box-sizing: border-box;
    margin: 30px;
    margin-top: 60px;
    padding: 30px;
    text-align: justify;
    box-shadow: 0 0 24px rgba(0, 252, 252, 0.3);
    width: 100%;
    
}

.button:hover {
    font: inherit;
    cursor: pointer;
    border-radius: 4px;
    border: 1px solid #0906d1;
    background-color: white;
    color: #06c4d1;
    text-decoration: none;
    padding: 10px 30px;
}

.button:hover,
.button:active {
    color: #fff;
    background-color: #ffffff;
}
 
.input-control {
    margin: 10px 0;
}
 
.input-control label {
    display: block;
    font-weight: bold;
    color: #ffffffc4;
}
 
.input-control input {
    display: block;
    width: 100%;
    box-sizing: border-box;
    font: inherit;
    border: 1px solid #ccc;
    border-radius: 4px;
    padding: 5px;
}
 
.input-control input:focus {
    background-color: #eee;
    outline: none;
}
 
</style>

