//Login.vue

<template>
  <v-app id="inspire">
    <v-main class="background">
      <v-form>
          <div class="centro">

         <v-card class="boxlogin">
            <h2 class="inisessao"> Iniciar Sessão</h2>

            <v-card-text>
               <v-text-field label="Username"/>
               <v-text-field label="Password" type="password" v-model="password"/>
               <v-text-field label="Email" type="email" v-model="email_" /> 
            </v-card-text>


            <v-card-actions>
               <v-btn type="button" @click="login()">
                  Login
               </v-btn>
            </v-card-actions>
            <div v-if="mostrar">
         <v-alert
            color="#2A3B4D" dark
            icon="mdi-firework"
            dense
      >
      Erro de autenticação 
    </v-alert>
    
      </div>
         </v-card>
         </div>
         
      </v-form>
      
    </v-main>
  </v-app>
  
</template>
<script>
import firebase from 'firebase';
   export default {
   data() {
      return {
         signup: false,
         email_ : "",
         password: '',
         mostrar: false,
      };
      },
   methods: {
      aparecer_signup(){
         this.signup = true;
         this.$router.push("/Registo");
      },

      login(){
         firebase.auth().signInWithEmailAndPassword(this.email_, this.password)
         .then((userCredential) => {
            // Signed in
            var user = userCredential.user;
            console.log(user);
            this.$router.push("/Produto");
             this.mostrar = false;
            // ...
         })
         .catch((error) => {
            var errorCode = error.code;
            var errorMessage = error.message;
            console.log(errorCode + errorMessage);
            //this.$router.push("/Registo");
            this.mostrar = true;
         });
      }


      },
   };

</script>



<style> 
   .boxlogin {
      width: 800px; 
      background-image: url("https://www.riccel.com.br/blog/wp-content/uploads/2019/11/Qualidade-Limpeza-hospital_Topo.jpg");   
      background-size: cover;
      background-position: center ;
   }

   .background {
      background-image: url("https://img.freepik.com/free-vector/abstract-medical-wallpaper-template-design_53876-61803.jpg?size=626&ext=jpg");
      background-size: cover;
      background-position: center;
   }

   .centro {
        display: flex;
         justify-content:flex-start;
        padding: 80px;
   }
   .inisessao {
      display: flex;
      justify-content: center;
      padding: 10px;
      
   }

</style> 
