<template>
    <v-container>
      <div class="inputbotao">
        <input type="text" placeholder="Insira o nome do paciente" class="inputt"  v-model="pesquisa" required v-on:keyup.enter="procura(pesquisa)">
            <v-icon class="botao" @click="procura(pesquisa)">mdi-magnify </v-icon> <!-- isto -->
      </div>
            
            <br>
            <br>

        <div class="colunaPesquisa">
        
            <div v-for="(api, index) in hospitalApi" :key="index">
            
              <img :src="api.images.small" />
            </div>
        </div>
    </v-container>
</template>



<script>
import axios from "axios";
export default {
    name: 'App',
    data() {
    return {
        info: null,
        pokeapi: null,
        favoritos: [],
        vertical: true,
        snackbar: false,
        text:'Esse item já foi adicionado aos favoritos',
        pesquisa: "",
        novoDoente: {
        nomeDoente: "",
      },
    };
  },
  mounted() {
    var that = this;
    axios
      .get("https://hospitalmadeira-default-rtdb.firebaseio.com/Doente.json")
      .then(response => (this.info = response.data.Doente));
    console.log(that.info);
  },
  methods:{
      submeterFormulario() {
      return axios.post("https://hospitalmadeira-default-rtdb.firebaseio.com/Doente.json",this.novoDoente
      );
    },

    procura(pesq){
        this.pesquisa = pesq;

    },
  }
}
</script>


<style scoped>

html, body {
    height: 100%;
    margin: 0;
    padding: 0;
}
#app {
    font-family: Avenir, Helvetica, Arial, sans-serif;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
    text-align: center;
    color: #2c3e50;
    margin-top: 60px;
}

.outer {
    display: flex;
    flex: 1;
    width: auto;
    height: 100%;
    padding: 0 20px;
    flex-flow: row nowrap;
    align-items: center;
}
.inner-content {
    flex-shrink: 0;
    align-items: center;
    justify-content: center;
    width: 100px;
    height: calc(100% - 40px);
    border: solid 1px #2c3e50;
    border-radius: 5px;
}
.inner-content:not(:first-of-type) {
    margin-left: 30px;
}
.colunaPesquisa {
  display: grid;
  grid-template-columns: 300px 300px 300px 300px 300px  ;
  padding-left: 70px;
  grid-gap: 30px;
  min-height: 800px;
  
}
.container {
  background-image: url("https://governmentciomedia.com/sites/default/files/styles/featured_article_image/public/2018-12/health-care-icon-pattern-medical-innovation-concept-background-design-vector-id861104740.jpg?itok=koiIi9fz");
  background-size: cover;
    background-position: center ;
  height:100%;
}

.inputt {
    background-color: white;
    width:400px;
    height: 50px;
    font-size: 26px;
    text-align: center;
    outline:none;
}
.botao {
  background-color: lightblue;
  height: 50px;
  width: 50px;
  border: solid 1px white;
  font-size: 36px;
}
.inputbotao {
  display: flex;
  justify-content: center;
  align-content: center;
}
</style>

<style></style>