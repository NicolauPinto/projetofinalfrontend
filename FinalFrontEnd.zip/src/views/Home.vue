<template>
  <div class="home">
    <div class="caixadetexto">
    <h1 class="titulo">Hospital Particular da Madeira</h1>
    <p class="paragrafos">Como todos sabemos, o COVID nos têm afetado em todos os niveis possiveis, desde o economico, até o social, não obstante, o setor mais afetado por toda esta pandemía é o setor da saude, os medicamentos são insuficientes, os hospitais ficam cheios dia trás dia logo de receber as pessoas infetadas pelo letal virus, e é isso o cenário que nos, como equipa vamos simular neste trabalho. Neste trabalho proposto pelo professor Magno, vai-se simular um hospital localizado na Ilha da Madeira, especificamente o Nelio Mendonça onde logo de uma temporada de verão exitosa onde as mortes e os casos foram diminuindo cada ves mais, agora estão em crise devido a nova cepa, algumas das atividades que vão ser simuladas neste trabalho são as seguintes:

-Receção de pessoas tanto regionais como estrangeiras infetadas pelo virus e ser asignadas a uma habitação com o seu respetivo medico e enfermeiros.
-Pesquisa de medicamentos para os doentes tanto infetados pelo virus tanto pelo outro tipo de doenças como o dengue e o virus H1N1
-Realização de consultas medicas</p>
<img class="imagem" src="https://www.grupohpa.com/static/images/logos/hospital_particular_da_madeira.png" alt="">
    </div>
  </div>
</template>

<script>
// @ is an alias to /src

export default {
  name: 'Home',
  components: {

  }
}

</script>

<style scoped>
html {
  height: 100%;
  width: 100%;
}
.home {
  background-image: url("https://www.grupohpa.com/uploads/media/1fb4ea76eb467caf7cd7b97f10476a9e_EtsDa1k.jpg") ;
  background-size: cover;
  background-position: center;
  height: 950px;
  display:flex;
  justify-content: center;
  align-items: center;
  
  
}
.caixadetexto {
  background-color: black;
  width: 1500px;
  height: 700px;
  opacity: 0.8;
  padding-left:30px;
  padding-right: 30px;

}
.titulo {
  color: white;
  text-align: center;
  margin-top: 45px;
  font-size: 75px;
}
.paragrafos {
  color: white;
  text-align: center;
  margin-top: 45px;
  font-size:25px;
}
.imagem {
  width: 340px;
  opacity: 1;
  margin-top: 20px;
  justify-content: center;
  align-content: center;
}

</style>

