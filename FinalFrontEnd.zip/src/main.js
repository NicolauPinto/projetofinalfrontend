import Vue from 'vue'
import App from './App.vue'
import router from './router'
import vuetify from './plugins/vuetify';
import firebase from 'firebase';



Vue.config.productionTip = false

new Vue({
  router,
  vuetify,
  render: h => h(App)
}).$mount('#app')

    
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
var firebaseConfig = {
  apiKey: "AIzaSyAEAcBTROz1fUrX5le26ezHJXJnLy2I_OE",
  authDomain: "hospitalmadeira.firebaseapp.com",
  databaseURL: "https://hospitalmadeira-default-rtdb.firebaseio.com",
  projectId: "hospitalmadeira",
  storageBucket: "hospitalmadeira.appspot.com",
  messagingSenderId: "42504775279",
  appId: "1:42504775279:web:63220d2686cb5c675d8f9a",
  measurementId: "G-KXYVQDL32V"
};
firebase.initializeApp(firebaseConfig);


